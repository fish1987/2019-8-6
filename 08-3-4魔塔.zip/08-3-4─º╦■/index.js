/**
 * yuanxin
 */

// (function () {
// 	// 准备资源 汪洋
	// const context = document.getElementById('content').getContext('2d');
	// const heroImg = new Image();

// 	// 画图 袁鑫
// 	heroImg.onload = function () {
// 		var imgPos = {
// 			x: 0, 
// 			y: 0,
// 			width: 32,
// 			height: 32
// 		};

// 		var rect = {
// 			x: 0,
// 			y: 0,
// 			width: 40,
// 			height: 40
// 		};

// 		context
// 			.drawImage(
// 				heroImg,
// 				imgPos.x,
// 				imgPos.y,
// 				imgPos.width,
// 				imgPos.height,
// 				rect.x,
// 				rect.y,
// 				rect.width,
// 				rect.height
// 			);
// 	};

// 	heroImg.src = './hero.png';
// })();



(function () {
	// 我是汪洋老师
	function prepare() {

		const imgTask = function(img, src){
			return new Promise(function (resolve, reject) {
				img.onload = resolve;
				img.onerror = reject;
				img.src = src;
			});
		};

		const context = document.getElementById('content').getContext('2d');
		const heroImg = new Image();
		const allSpriteImg = new Image();

		const allresourceTask = Promise.all([
			imgTask(heroImg, './hero.png'),
			imgTask(allSpriteImg, './all.jpg'),
		]);

		return {
			/**
			 * @param {Function} [callback] - 当准备好了之后要调用的回掉函数
			 */
			getResource(callback) {
				allresourceTask.then(function () {
					callback && callback(context, heroImg, allSpriteImg);
				});
			}
		};
	}


	// 我是袁鑫老师
	function drawHero(context, heroImg, allSpriteImg) {
       
		var draw = function () {
			this.context.drawImage(
					this.img,
					this.imgPos.x,
					this.imgPos.y,
					this.imgPos.width,
					this.imgPos.height,
					this.rect.x,
					this.rect.y,
					this.rect.width,
					this.rect.height
				);
		}
		
		document.onkeydown = function move (e) {
                if(e.keyCode == 40){
                   this.rect.x++,
                    this.imgPos.y++;
                    this.draw();
                    /*前*/
                }else if(e.keyCode == 37){
                     this.rect.x++,
                     this.imgPos.y++;
                     this.draw();
                    /*左*/
                }else if(e.keyCode == 39){
                     this.rect.x++,
                     this.imgPos.y++;
                     this.draw();
                    /*右*/
                }else if(e.keyCode == 38){
                    this.rect.x++,
                    this.imgPos.y++;
                    this.draw();
                    /*后*/
                }
            }


// 		var hero = {
// 			img: heroImg,
// 			context: context,
// 			imgPos: {
// 				x: 0,
// 				y: 0,
// 				width: 32,
// 				height: 32
// 			},
// 
// 			rect: {
// 				x: 0,
// 				y: 0,
// 				width: 40,
// 				height: 40
// 			},
// 
// 			draw: draw,
// 			
// 		};
		function Hero(posi){
			this.img = heroImg
			this.context = context
			this.imgPos = {
				x: 0,
				y: 0,
				width: 32,
				height: 32
			}
			this.rect = {
				x: posi.x,
				y: posi.y,
				width: 40,
				height: 40
			}
		}
		Hero.prototype.draw = draw
		Hero.prototype.move = move
		var hero1 = new Hero({x:0,y:0})
		hero1.draw()
		hero1.move()
		
		
		
// 		var monster = {
// 			img: allSpriteImg,
// 			context: context,
// 			imgPos: {
// 				x: 858,
// 				y: 529,
// 				width: 32,
// 				height: 32
// 			},
// 
// 			rect: {
// 				x: 100,
// 				y: 100,
// 				width: 40,
// 				height: 40
// 			},
// 
// 			draw: draw
// 		};

// hero.draw();
// monster.draw();
		
		function Monster(postion){
			this.img =  allSpriteImg
			this.context = context
			this.imgPos = {
				x:858 ,
				y:529 ,
				width: 32,
				height: 32
			}
			this.rect={
				x: postion.x,
				y: postion.y,
				width: 40,
				height: 40
			}
		}
		
		Monster.prototype.draw = draw
		var monster1 = new Monster({x:100,y:30})
		var monster2 = new Monster({x:100,y:100})
		// var monster1 = new Monster({x:100,y:30},{x:858,y:529})
		// var monster2 = new Monster({x:100,y:100},{x:232,y:790})
		monster1.draw()
		monster2.draw()
		function Heart (postion){
			Monster.call(this,postion)
			this.imgPos = {
				x:232 ,
				y:790 ,
				width: 32,
				height: 32
			}
		}		
		Heart.prototype = Object.create(Monster.prototype)
		var heart = new Heart({x:150,y:150})
		heart.draw()
	}
	 
	
	
	
	

	var resourceManager = prepare();
	resourceManager.getResource(function (context, heroImg, allSpriteImg) {
		drawHero(context, heroImg, allSpriteImg);
	});
	
	
})();